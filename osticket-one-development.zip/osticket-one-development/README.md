# osticket-one
OS Ticket one theme
Documentation : https://zaliyo.github.io/osticket-one/
